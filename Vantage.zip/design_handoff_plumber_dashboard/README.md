# Handoff: Plumber — Audit Harness Dashboard

## Overview
Plumber is a self-hosted performance-audit harness. Its job is to turn "I think it's slow" into a defensible statement: *here is the number, here is where the time goes, and here is proof the change moved it — beyond noise, and not by accident.* Its unit of work is the **comparison** (baseline run vs candidate run), not a live stream.

This handoff covers the **web dashboard** (spec §10), delivered in **two complete visual directions**:

1. **`Plumber Dashboard.dc.html`** — a **dark "instrument panel"** with a full 5-view app (Targets, Run, Result, Compare, Report) switched from a left rail. This is the primary/canonical direction.
2. **`Plumber Overview (Uptime).dc.html`** — a **light "uptime-monitor"** direction (single Overview screen) inspired by a monitoring-dashboard aesthetic: navy sidebar, white cards, circular uptime rings, response-time area chart, and segmented run-history bars.

Both render the same data universe (target *Sluice / GET /positions*, SLO `p99 ≤ 150ms @ 200rps`, an N+1 query in the positions load, a `−220ms` p99 improvement with 95% CI `[180, 255]`, "conditions match → causal").

## About the Design Files
The files in this bundle are **design references authored in HTML** — prototypes showing intended look and behavior, **not production code to copy directly**. They are built as "Design Components" (a streaming-template runtime): a `.dc.html` file plus a `support.js` runtime. **Do not port `support.js` or the `<x-dc>` / `{{ }}` template syntax** — it is a prototyping harness, not part of the target app.

The task is to **recreate these designs in the target codebase's environment** (the spec calls for **React + TypeScript**, charts via Recharts or similar) using its established components and patterns. If no frontend exists yet, React + TS + a charting lib is the intended stack. All layout/logic in the `.dc.html` files is expressed with plain inline styles and a small logic class returning view data — read them as a spec for markup + values, then rebuild idiomatically.

The dashboard is explicitly a **later presentation layer over the same `app` API** used by the CLI seam (spec §11); build it against that API, not against hardcoded data.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, and interactions. Recreate pixel-faithfully using the codebase's libraries. Colors are authored in **OKLCH** (exact); approximate hex is given in Design Tokens for convenience — prefer carrying the OKLCH values through if the stack supports them (all evergreen browsers do).

---

## Direction 1 — Dark Instrument Panel (`Plumber Dashboard.dc.html`)

Fixed 2-column app shell, full viewport height. Left rail (236px) + main column (flex). Main column = fixed header (60px) + scrolling body (28px padding). Design preview size 1280×860.

### Global chrome

**Sidebar (236px, bg `oklch(0.185 0.008 250)`, right border `oklch(0.26 0.008 250)`)**
- **Brand lockup**: a "plumb line" mark (24px: a 1.5px vertical line, an 11px downward triangle via `clip-path:polygon(50% 100%,0 0,100% 0)`, a 6px ring at top — all `oklch(0.74 0.11 210)`) + wordmark "Plumber" (700/16px) and "audit harness" (mono 9.5px, uppercase, letter-spacing .06em, `oklch(0.55 0.008 250)`).
- **Nav** (5 items, 2px gap, each a full-width button, 9px×10px padding, radius 8px, 13px/500):
  - glyph (mono 10px, 16px wide) · label (flex) · slice tag (mono 9px/600).
  - Items & slice tags: `Targets ◈ S0`, `Run ▸ S1`, `Result ▤ S5`, `Compare ⇄ S3`, `Report ❐ S7`.
  - Slice-tag color encodes **tier**: MVP (`S1`, `S3`) = `oklch(0.7 0.12 150)` green; deferred (`S0`, `S5`, `S7`) = `oklch(0.5 0.008 250)` grey.
  - Active item: bg `oklch(0.24 0.02 210)`, text `oklch(0.95 0.005 250)`, glyph tinted to the accent. Inactive text `oklch(0.68 0.008 250)`. Hover bg `oklch(0.24 0.01 250)`.
  - **Default active view: `Compare`.**
- **Tier legend** (below nav): two 7px squares + labels "MVP tier · S1–S3" (green) / "deferred" (grey), mono 9px.
- **Active-target card** (bottom, radius 8px, bg `oklch(0.21 0.008 250)`): green status dot + "Sluice" (600/13px), "GET /positions" (mono 11px), two pills — "white-box" (`oklch(0.28 0.03 210)` bg / `oklch(0.8 0.09 210)` text) and "staging" (`oklch(0.26 0.008 250)` / `oklch(0.68 0.008 250)`).

**Header (60px, bg `oklch(0.175 0.008 250)`, bottom border `oklch(0.26 0.008 250)`, 28px horiz padding, space-between)**
- Left: breadcrumb (mono 12px) — "Sluice / GET /positions" (`oklch(0.55…)`) · `›` (`oklch(0.4…)`) · **current view name** (`oklch(0.9…)`/500).
- Right: SLO reminder "SLO  p99 ≤ 150ms @ 200rps" (mono 11px) + a **contextual verdict pill** (6px×12px padding, radius 7px, 7px dot + mono 11px/600 label). The pill changes per view:
  - Compare/Report → "SIGNIFICANT" (green: bg `oklch(0.26 0.05 150)`, border `oklch(0.42 0.08 150)`, dot `oklch(0.78 0.14 150)`, text `oklch(0.85 0.12 150)`).
  - Result → "p99 FAIL · 380ms" (red family, hue 30).
  - Run → "RUNNING · 5/7" (neutral, green dot).
  - Targets → "4 ALLOWLISTED" (neutral, accent dot).

### View: Compare (default / hero)
Purpose: prove a change moved the metric beyond noise, and that the move is causal.

1. **Header row**: title "Compare" (23px/700, letter-spacing −.02em) + subtitle "Baseline vs candidate — bootstrap CI on the delta, over successful requests only." (`oklch(0.62…)`/13px). Right: two chips (mono 11px) — `baseline before-fix · a3f21c` and `candidate after-index · 7b90e4`.
2. **Hero grid** (`1.15fr 1fr`, 16px gap):
   - **Verdict card** (radius 14px, border `oklch(0.4 0.09 150)`, bg linear-gradient 180° `oklch(0.24 0.05 150)`→`oklch(0.2 0.02 155)`, 26×28 padding): "SIGNIFICANT" eyebrow (mono 12px/600, letter-spacing .16em, `oklch(0.82 0.14 150)`) + rule; big **`−220ms`** (mono 52px/600, `oklch(0.88 0.13 150)`; "ms" 24px) beside "p99 improved" + "95% CI [180, 255]"; body copy about CI excluding zero across 7 reps and the move being causal.
   - **SLO-verdict card** (radius 14px, border `oklch(0.28 0.01 250)`, bg `oklch(0.19 0.008 250)`): row "SLO verdict (candidate)" + red "FAIL" pill; mono body `p99 = 160ms › target 150ms`, "missed by 10ms — significant gain, still short of the line."; divider; footnote "7 reps · constant 200rps · warmup 10s · Δoverhead 0.4ms".
3. **Environment-comparability card** (radius 14px, border `oklch(0.36 0.05 150)`, bg `oklch(0.185 0.012 155)`) — the key correctness feature:
   - Header: "Environment comparability" + green pill "CONDITIONS MATCH" (bg `oklch(0.28 0.06 150)` / text `oklch(0.84 0.12 150)`); right note (mono 11px) "a tight CI proves precision · matching conditions prove causation".
   - 4-col grid of fingerprint cards (radius 9px, bg `oklch(0.21 0.008 250)`): label (mono 9.5px uppercase) + `base → cand` (mono 12.5px) + a right-aligned ✓ in `oklch(0.78 0.13 150)`. Rows: **dataset rows** `1.04M → 1.04M`, **schema version** `v128 → v128`, **cache state** `warm → warm`, **host · coloc.** `staging-01 → staging-01`.
   - Footer copy: same box / back-to-back / no drift → the −220ms is the index, not tables growing; and "Divergent conditions would downgrade this verdict to `confounded`" ("confounded" in `oklch(0.82 0.12 55)`).
4. **Metric delta table** (radius 14px, bg `oklch(0.19 0.008 250)`): 5-col grid `1.1fr 1fr 1fr 1.4fr 1.3fr` = metric · baseline · candidate · `Δ 95% CI` · verdict. Header row mono 10px uppercase `oklch(0.55…)`. Body rows (15×22 padding, bottom border `oklch(0.23 0.008 250)`): metric (mono 13px/500), baseline (`oklch(0.62…)`), candidate (`oklch(0.9…)`), delta (colored: green `oklch(0.78 0.11 150)` when significant-improvement else muted `oklch(0.6…)`) + CI (`oklch(0.5…)`), and a verdict badge. Rows:
     | metric | baseline | candidate | Δ · 95% CI | verdict |
     |---|---|---|---|---|
     | p50 | 42ms | 38ms | −4ms · [−7, +1] | within-noise |
     | p90 | 120ms | 74ms | −46ms · [−52, −40] | significant |
     | p99 | 380ms | 160ms | −220ms · [−255, −180] | significant |
     | p99.9 | 520ms | 210ms | −310ms · [−360, −262] | significant |
     | error_rate | 0.02% | 0.01% | −0.01% · [−0.03, +0.01] | within-noise |
     | throughput | 198rps | 200rps | +2rps · [−3, +7] | within-noise |
   - Badge styles: **significant** = bg `oklch(0.26 0.05 150)` / text `oklch(0.84 0.12 150)`; **within-noise** = bg `oklch(0.26 0.008 250)` / text `oklch(0.66 0.008 250)`. (Third state **confounded** — not shown in this dataset — should use the caution hue ~55.)
   - Table footnote (mono 10.5px): "latency percentiles cover successful requests only · error_rate is a co-equal axis, not folded into the tail".

### View: Result
Purpose: the distribution, the load knee, and where the tail's time goes for one run (before-fix).
1. Title "Result · run before-fix · a3f21c" + subtitle mentioning success-only.
2. **Stat strip**: 6 cards (radius 11px), each label (mono 10px uppercase) + big value (mono 23px/600) + unit (mono 10px). Values: p50 **42**ms, p90 **120**ms, p99 **380**ms (`oklch(0.85 0.12 75)` amber), p99.9 **520**ms (`oklch(0.82 0.13 30)` red), rps **198** (achieved), err **0.02** (% (co-axis)).
3. **Two-up** (`1fr 1fr`, 16px):
   - **Latency distribution** histogram: 30 bars (`align-items:flex-end`, 2px gap, radius 2px top). Bar heights come from a fixed count array normalized to max; bars at/after the p99 bucket (index 19 of 30) are amber `oklch(0.7 0.12 75)`, mid buckets (≥6) `oklch(0.5 0.06 210)`, early buckets = accent. A dashed vertical marker at the p99 position (`oklch(0.8 0.12 75)`). Axis labels "0ms / ↑ p99 380ms / 600ms".
   - **Throughput → latency & errors** knee chart (inline SVG, viewBox 0 0 600 200): x = rps (50→350 over x 40..560), left y = latency 0..1000ms, right y = error 0..15%. **Blue** p99 line + faint area (accent, hue 210) through points (50,45)(100,60)(150,95)(200,160)(250,290)(300,480)(350,920); **red** dashed-solid error line (`oklch(0.7 0.16 30)`) through (50,.01)(100,.01)(150,.02)(200,.03)(250,.12)(300,1.8)(350,14.2); vertical dashed knee marker at 250rps (`oklch(0.8 0.12 75)`) labeled "knee ≈ 250 rps — errors climb"; the 250-rps dot enlarged. Small legend row above: "p99 latency" (accent swatch) / "error rate" (red swatch).
4. **Tail exemplar — span waterfall** (radius 14px): header "… · white-box · S5 deferred tier" + "trace 4b1f… · p99 request · captured 381ms"; caption "The *slow* request pulled by trace-id — not an average over the window." Then 6 rows, each: a **250px** left label (mono 11.5px, indented `depth×16px`), a flex track (18px, bg `oklch(0.215 0.008 250)`, radius 4px) with an absolutely-positioned bar (`left%`/`width%` from start/duration over 380ms total), and a **64px** right ms value. Spans (name, start→dur): `GET /positions` 0→380 (accent, handler); `auth.verify` 4→8; `positions.load` 14→360; `db.query accounts` 16→12; **`db.query positions ×47 (N+1)` 30→340 (hot: bar `oklch(0.68 0.13 30)`, text `oklch(0.84 0.12 30)`)**; `serialize` 376→2. Non-hot child bars `oklch(0.5 0.06 210)`.
5. **Query attribution** table (radius 14px): header "pg_stat_statements delta · run window"; 5-col grid `3fr 0.7fr 1fr 0.9fr 1fr` = statement · calls · total · mean · flag. Rows: `SELECT * FROM positions WHERE account_id = $1` — 47 / 338ms / 7.2ms / **N+1** (red pill, statement + calls in red); `SELECT * FROM accounts WHERE id = $1` — 1 / 12ms / 12.0ms; `BEGIN / COMMIT` — 1 / 2ms / 2.0ms.

### View: Targets
Purpose: manage allowlisted services. Header "Targets" + subtitle "Allowlisted services under audit. No allowlist entry → no load." + blue "+ add target" button. Each target = card (radius 12px, 5-col grid `1.5fr 1.4fr 1fr 1fr auto`): name + status dot + endpoint (mono); SLO (mono); mode pill (white-box → hue-210 pill, black-box → grey pill); env pill + optional red "mutating ⚠" pill; right-aligned status text (colored). Rows:
- **Sluice** `GET /positions` — p99 ≤ 150ms @ 200rps — white-box — staging — *baselined* (green). Card border tinted `oklch(0.34 0.03 210)`.
- **Sluice** `GET /ohlc/vwap (pipeline)` — p99 ≤ 120ms @ 300rps — white-box — staging — *first target* (green `oklch(0.7 0.12 150)`), card border `oklch(0.36 0.05 150)`.
- **Orchard** `POST /orders` — p99 ≤ 300ms @ 100rps — white-box — staging — **mutating ⚠** — *ready* (grey), card border `oklch(0.34 0.05 30)`.
- **external-quotes** `GET /v1/quote` — p99 ≤ 250ms @ 50rps — **black-box** — staging — *baselined* (green).

### View: Run
Purpose: configure + watch a run. `1fr 1.3fr` grid.
- **Profile card**: key/value rows — Profile `constant`, Rate `200 rps`, Duration / rep `60s`, Repetitions (N) `7`, Warmup discard `10s`, Env fingerprint `captured`. Red "■ ABORT (drains in-flight)" button (border `oklch(0.45 0.14 30)`, bg `oklch(0.32 0.09 30)`).
- **Live card** (green-tinted, border `oklch(0.38 0.06 150)`, bg `oklch(0.19 0.01 155)`): pulsing dot (`@keyframes plumb-pulse` opacity 1→.35, 1.4s) + "Running — rep 5 of 7"; 3 big metrics (mono 24px) — achieved rps **199.4**, error rate **0.01%**, p99 (running) **158ms** (amber); a 7-segment "repetitions" bar (4 done `oklch(0.6 0.1 150)`, 1 active `oklch(0.78 0.14 150)`, 2 pending `oklch(0.3 0.01 250)`); an indeterminate progress bar with a sweeping highlight (`@keyframes plumb-sweep` translateX −100%→400%, 1.6s linear); footnote "elapsed 4m 12s · env: 1.04M rows · warm · staging-01".

### View: Report
Purpose: the shareable AuditReport artifact. Header + three export buttons: "↓ Markdown" (blue), "↓ HTML" (grey), "PDF · deferred" (disabled). Body: a 760px-max "document" card (radius 14px, bg `oklch(0.185 0.008 250)`, 38×44 padding) rendered entirely in mono 13px/line-height 1.7, styled like a Markdown source view with `#`/`##` headings in `oklch(0.55…)`. Sections: title `# Audit — Sluice / GET /positions`; **verdict** SIGNIFICANT (green) "— p99 −220ms, 95% CI [180, 255], conditions match → causal"; **slo** FAIL (red) "— p99 160ms > 150ms target (missed by 10ms)"; `## Conditions (env fingerprint)` rows 1.04M=1.04M · schema v128 · warm/warm · host staging-01 (same box) → no drift; `## Hotspot` 340/380ms is the N+1; `## Evidence` bullets (tail exemplar trace, EXPLAIN attached, 7 reps · success-only); `## Delta` p50/p90/p99/p99.9 with per-line significant/within-noise coloring.

---

## Direction 2 — Light Uptime Monitor (`Plumber Overview (Uptime).dc.html`)
Single **Overview** screen. 2-column: navy sidebar (230px) + light main. Preview size 1280×900. Canvas bg `oklch(0.97 0.005 255)`; all content cards are white (`oklch(1 0 0)`), radius **16px**, border `oklch(0.93 0.004 255)`, shadow `0 1px 3px oklch(0.4 0.02 262 / 0.06)`.

- **Sidebar** (navy `oklch(0.26 0.035 262)`): same plumb-line mark (teal `oklch(0.72 0.12 190)`) + wordmark (white). Nav (10×12 padding, radius 9px): `Overview ◱` (active: bg `oklch(0.32 0.05 262)`, white, teal glyph), `Targets ◈` (count pill "4"), `Runs ▸` (count "12"), `Compare ⇄`, `Reports ❐`. Inactive text `oklch(0.74 0.02 262)`. Bottom status card: pulsing green dot + "All systems nominal" + "4 targets · 1 SLO breach".
- **Topbar** (66px, white, bottom border): "Overview" (17px/700) + "Sluice · staging · last 12 audit runs"; right = green "CI PROVEN · CAUSAL" chip + blue "+ New run" button (bg `oklch(0.62 0.12 245)`, white, radius 9px).
- **Stat cards** (4-col, 18px gap):
  1. **Checks passing** — 76px SVG donut (r=30, track `oklch(0.93 0.01 255)`, arc green `oklch(0.68 0.16 155)` at **83%** via `stroke-dasharray`, rotate −90) with centered "83%"; text "5 / 6" (mono 24px) + "this run · p99 over SLO".
  2. **Availability** — same donut in blue `oklch(0.62 0.12 245)` at **99.8%**; "99.8%" + "30-day, success rate".
  3. **p99 latency** — "160ms" (mono 26px) + green "▼ 58%" pill + green sparkline (SVG polyline, values dropping ~380→160).
  4. **Throughput** — "200rps" + blue "▲ 1%" pill + blue sparkline.
- **Chart + Latest-compare** row (`1.9fr 1fr`):
  - **p99 latency — last 12 runs** area chart (SVG viewBox 0 0 720 240): 3 faint gridlines; blue line+area (`oklch(0.62 0.14 245)`) over runs `[372,388,365,381,392,377,168,159,162,155,161,158]` (y-scale 0..420ms over y 200→14); amber dashed **SLO 150ms** line; green dashed vertical "index added" marker between run 6 and 7; per-run dots colored green if ≤150ms else amber, last dot enlarged + blue. X labels: run 1 / before-fix / after-index / run 12. Legend: p99 (blue) / SLO 150ms (amber dashed).
  - **Latest comparison** card (green gradient bg `oklch(0.97 0.03 155)`→white, border `oklch(0.87 0.05 155)`): "SIGNIFICANT" + "CONDITIONS MATCH" pill; huge **`−220ms`** (mono 44px, `oklch(0.46 0.14 155)`); "p99 · before-fix → after-index"; "95% CI [180, 255]"; divider; copy about the N+1 and causal win; "View audit report →" link (blue).
- **Targets monitor list** (white card): header "Targets" + "pass rate over last 12 runs". 5-col grid `2fr 2.4fr 0.8fr 0.9fr 1.1fr` = monitor · run history · pass · p99 · verdict; header row on `oklch(0.975 0.004 255)`. Each row: status dot + name (+ red "MUT" tag if mutating) + endpoint (mono); a **segmented run-history bar** = flex row of 12 thin bars (2.5px gap, radius 2px), height & color per run status — **g** = pass (green `oklch(0.7 0.15 155)`, 22px), **a** = within-noise (amber `oklch(0.8 0.13 75)`, 16px), **r** = fail (red `oklch(0.66 0.19 25)`, 11px); pass % (colored); p99; verdict pill. Rows:
  - **Sluice** `GET /positions` — history `r r a a r r g g g g g g` (the fix: red→green) — **83%** — 160ms — *significant*.
  - **Sluice** `GET /ohlc/vwap (pipeline)` — all green — **100%** — 96ms — *first target* (blue pill).
  - **Orchard** `POST /orders` — **MUT** — `g g a g g g a g g g g a` — **92%** (amber) — 280ms — *within-noise* (grey pill).
  - **external-quotes** `GET /v1/quote` — one red run — **96%** — 210ms — *pass*.

---

## Interactions & Behavior
- **View switching (Direction 1)**: the left-rail items set the active view (`Targets | Run | Result | Compare | Report`); the header breadcrumb tail and the contextual verdict pill both derive from the active view. Default view is **Compare**. Hover states on nav (bg lighten) and buttons (bg lighten). No route/URL in the prototype — wire to your router; deep-linking each view is recommended.
- **Direction 2** nav is presentational in the prototype (single Overview screen); implement the other destinations as real routes.
- **Live run (Direction 1 / Run view)**: two CSS keyframes — `plumb-pulse` (status dot, opacity 1↔0.35, 1.4s ease-in-out infinite) and `plumb-sweep` (progress highlight, translateX −100%→400%, 1.6s linear infinite). In production, drive the achieved-rps / error-rate / running-p99 / rep-progress from the run stream (SSE/websocket) exposed by the `app` API.
- **Charts**: all charts are data-driven (points computed from arrays). Rebuild with the codebase's charting lib (Recharts per spec) — keep the reference lines (SLO threshold, knee marker, "index added" marker), the dual-axis latency+error knee curve, and the success-only semantics.
- **Verdict semantics (must be honest — this is the product's whole point)**:
  - `Judge` (single run vs SLO) → per-metric **PASS/FAIL**, needs no baseline.
  - `Compare` (baseline vs candidate) → per-metric **Δ + 95% CI** and a judgment: **significant** (CI excludes zero), **within-noise** (CI includes zero), **incomparable** (mismatched profile / N=1), or **confounded** (env-fingerprint drift). Never render a bare delta without its CI and judgment.
  - Latency percentiles are computed over **successful requests only**; **error_rate is a co-equal axis**, never folded into the tail.

## State Management
Recommended state (dashboard is a read layer over the `app` API):
- `activeView` (Direction 1) / route.
- `activeTargetId`; targets list (name, endpoint, mode, env, mutating, allowlisted, SLOs, baseline status).
- Selected `baselineRunId` + `candidateRunId` for Compare; the resulting `Delta` (per-metric point estimate, CI, judgment) + `env_fingerprint` diff.
- Selected `runId` for Result → pooled percentiles, per-rep variance, histogram, knee series (latency + error), tail exemplar span tree, query attribution.
- Live run stream for the Run view (achieved rps, running error rate, running p99, reps completed/total, elapsed, env fingerprint).
- Runs history series for Direction 2's trend chart and per-target run-history bars.

## Data fetching
All numbers shown are **sample data** baked into the prototypes. Replace with the `app`/store API (spec §5–§6). Entities: `targets`, `slos`, `runs` (with `env_fingerprint`), `reps` (success-only HDR histograms + per-rep percentiles), `exemplars` + `spans`, `query_attrib`, `baselines`. Pooled percentiles are derived by merging rep histograms on read; per-rep percentiles supply the variance the bootstrap CI needs.

## Design Tokens

### Typography
- **UI sans**: `'IBM Plex Sans', system-ui, sans-serif`.
- **Numeric / metrics / code**: `'IBM Plex Mono', monospace` — used for all numbers, tags, table cells, breadcrumb, report body.
- Sizes seen: 52 / 44 (hero delta), 26 / 24 / 23 (big stats & titles), 17 / 16 / 15, 13.5 / 13 / 12.5 / 12 / 11.5 (body & cells), 11 / 10.5 / 10 / 9.5 / 9 (tags, eyebrows, axis). Weights 400/500/600/700. Title letter-spacing −0.02em; eyebrow/uppercase +0.06–0.16em.

### Color — Direction 1 (dark), OKLCH (≈ hex)
- Canvas / body bg `oklch(0.16 0.008 250)` (≈ #14161a) · sidebar `oklch(0.185 0.008 250)` (≈ #1b1d21) · header `oklch(0.175 0.008 250)` · card `oklch(0.19 0.008 250)` (≈ #1c1e22) · inset/track `oklch(0.21 0.008 250)`.
- Borders: `oklch(0.26 0.008 250)` / `oklch(0.28 0.01 250)` / row `oklch(0.23 0.008 250)`.
- Text: primary `oklch(0.92 0.005 250)` (≈ #e6e7e9) · strong `oklch(0.9 0.005 250)` · muted `oklch(0.6–0.62 0.008 250)` · faint `oklch(0.5–0.55 0.008 250)`.
- Accent (tweakable, see below) default **purple** `oklch(0.72 0.13 300)` (≈ #a06bd6). Other curated options: `oklch(0.74 0.11 210)` blue, `oklch(0.72 0.12 155)` green, `oklch(0.76 0.12 75)` amber.
- Semantic: **good/significant** green `oklch(0.78 0.11 150)` (chips at 0.26/0.05/150 bg, 0.84/0.12/150 text) · **bad/fail** red hue 30 (`oklch(0.82 0.12 30)` text, `oklch(0.3 0.07 30)` bg) · **caution/p99** amber `oklch(0.85 0.12 75)` · **confounded** hue ~55 `oklch(0.82 0.12 55)` · chart secondary blue `oklch(0.5 0.06 210)` · error line `oklch(0.7 0.16 30)`.

### Color — Direction 2 (light), OKLCH
- Canvas `oklch(0.97 0.005 255)` · card white `oklch(1 0 0)` · border `oklch(0.93 0.004 255)` · row divider `oklch(0.955 0.004 255)` · table header bg `oklch(0.975 0.004 255)`.
- Sidebar navy `oklch(0.26 0.035 262)`; active item `oklch(0.32 0.05 262)`; count pill `oklch(0.34 0.04 262)`; sidebar text `oklch(0.74 0.02 262)`.
- Ink `oklch(0.30 0.02 262)` / `oklch(0.28 0.02 262)`; muted `oklch(0.56 0.015 262)`.
- Accent (tweakable) default **purple** `oklch(0.6 0.16 300)` (user-set). Curated options: `oklch(0.62 0.12 245)` blue, `oklch(0.68 0.12 190)` teal, `oklch(0.66 0.15 155)` green, `oklch(0.6 0.16 300)` purple.
- Semantic: green `oklch(0.68–0.7 0.15–0.16 155)` (pass) · amber `oklch(0.8 0.13 75)` (within-noise) · red `oklch(0.66 0.19 25)` (fail) · chart blue `oklch(0.62 0.14 245)` · SLO line `oklch(0.72 0.14 75)`.

### Shape & elevation
- Radius: 16px (light cards), 14px (dark cards), 11–12px (small cards/pills-container), 9px (nav / buttons / inset), 8px (chips), 5–6px (badges), 2–4px (bars).
- Shadow (light only): `0 1px 3px oklch(0.4 0.02 262 / 0.06)`; button `0 1px 2px <accent>/0.4`.
- Spacing rhythm: page padding 26–28px; card padding 18–26px; grid/gap 12–18px.

### Tweakable props (prototype "Tweaks" → real props)
Both files expose a single **`accentColor`** prop (curated OKLCH swatch set, editor type "color", grouped under "Theme"). Direction 1 default `oklch(0.72 0.13 300)`; Direction 2 default `oklch(0.6 0.16 300)`. In the target app, surface this as a theme accent token. The accent recolors: active-nav tint, brand/knee-chart lines, histogram early bars, waterfall handler bar (Direction 1) and the primary button/links (Direction 2).

## Assets
No external image/icon assets. The "plumb line" brand mark is pure CSS/SVG (line + triangle via `clip-path` + ring). All glyphs are Unicode geometric characters (`◈ ▸ ▤ ⇄ ❐ ◱ ✓ › ▼ ▲ ■ ⚠`) rendered in IBM Plex Mono — replace with your icon set as desired. Fonts: **IBM Plex Sans** + **IBM Plex Mono** (Google Fonts). Charts, rings, sparklines, histograms, and waterfalls are inline SVG / flex-div constructs — rebuild with your charting library.

## Files
- `Plumber Dashboard.dc.html` — Direction 1 (dark, 5 views). *Reference only.*
- `Plumber Overview (Uptime).dc.html` — Direction 2 (light, Overview). *Reference only.*
- `SPEC.md`, `SPEC-2.md` — the product spec (v2, then v3). §10 defines the frontend surfaces; §7/§8 define the verdict semantics the UI must present honestly.
- (`support.js` — the prototype runtime; **do not port**.)
