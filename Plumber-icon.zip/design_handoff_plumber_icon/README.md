# Handoff: Plumber — App Icon

## Overview
The app/product icon for **Plumber** (a performance-audit harness). The mark is a **plumb line**: a graduated horizontal reference bar with an anchor ring, a hanging cord, and a plumb-bob (an elongated faceted diamond) suspended over a faint dashed "true vertical" guide. Concept: a plumb line establishes ground truth / true vertical — exactly what the product does for latency numbers.

## About the Design Files
The files here are **design references authored in HTML/SVG** (a "Design Component" prototype), **not production assets**. The icon geometry is a plain inline `<svg viewBox="0 0 512 512">`. To implement: **lift the SVG geometry below and render it as a real asset** in the target toolchain — an `.svg` source exported to the PNG/ICO sizes the platform needs (iOS/Android/macOS/favicon), or an SVG React component. Do **not** ship the `.dc.html` wrapper or `support.js`.

- `Plumb Tile.dc.html` — the icon mark itself (one `<svg>`, themeable). **This is the source of truth for the geometry.**
- `Plumber Icon.dc.html` — a presentation sheet (hero + squircle/circle/light tile variants + 128/64/32/16 size strip). Reference only.

## Fidelity
**High-fidelity.** Final geometry, colors (OKLCH), and composition. Reproduce exactly.

## The mark — exact SVG geometry
`viewBox="0 0 512 512"`. Tile is the full 512×512 field; the rounded-corner shape is applied by the **container** (`border-radius` + `overflow:hidden`), not the SVG — so the same artwork serves square, squircle, and circle.

Draw order (back → front):
1. **Tile background** — linear-gradient `155deg, <tileTop> → <tileBot>` filling the whole tile.
2. **True-vertical guide** — `<line x1=256 y1=44 x2=256 y2=474>` stroke `<guide>`, width 2, `stroke-dasharray="6 10"`, round caps.
3. **Graduation ticks** — group stroke `<tick>`, width 3, round caps; eight short verticals at x = 182,200,218,236,276,294,312,330, each from y=98 down to y=108 (short) or y=112 (long, on x=182,218,294,330).
4. **Reference bar** — `<line x1=158 y1=94 x2=354 y2=94>` stroke `<ink>`, width 11, round caps.
5. **Anchor ring** — `<circle cx=256 cy=96 r=15 fill=none>` stroke `<ink>`, width 6.
6. **Cord** — `<line x1=256 y1=112 x2=256 y2=300>` stroke `<ink>`, width 5.
7. **Accent glow** — `<circle cx=256 cy=374 r=104>` fill `<accent>`, `opacity=0.16`.
8. **Plumb bob** — `<polygon points="256,298 306,352 296,400 256,454 216,400 206,352">` fill `<accent>`.
9. **Bob shade facet (left)** — `<polygon points="256,298 206,352 216,400 256,454">` fill `rgba(0,0,0,0.16)`.
10. **Bob center edge** — `<line x1=256 y1=300 x2=256 y2=452>` stroke `rgba(0,0,0,0.18)`, width 1.5.
11. **Tip highlight** — `<circle cx=256 cy=454 r=5>` fill `rgba(255,255,255,0.85)`.

## Color themes (OKLCH)
Named CSS-ish variables used above. Two shipped themes:

**Dark (primary):**
- tileTop `oklch(0.27 0.035 285)` · tileBot `oklch(0.14 0.02 282)`
- ink `oklch(0.9 0.012 260)` · tick `oklch(0.58 0.035 285 / 0.6)` · guide `oklch(0.68 0.045 285 / 0.42)`

**Light:**
- tileTop `oklch(0.99 0.004 250)` · tileBot `oklch(0.93 0.006 255)`
- ink `oklch(0.32 0.02 265)` · tick `oklch(0.6 0.02 265 / 0.45)` · guide `oklch(0.55 0.03 265 / 0.35)`

**Accent (bob + glow), tweakable** — default **purple** `oklch(0.72 0.13 300)`. Alternates: `oklch(0.74 0.11 210)` blue, `oklch(0.76 0.14 70)` amber-brass, `oklch(0.72 0.14 155)` green. (If your pipeline needs sRGB hex: purple ≈ `#a06bd6`, blue ≈ `#3fa7d6`, amber ≈ `#d69a3c`, green ≈ `#3fbd86` — prefer carrying OKLCH through where supported.)

## Tile shapes & sizes
- **Shape**: apply via container radius — squircle `border-radius:23%`, circle `50%`, or square `0`. Provide at least squircle (iOS/macOS) + a maskable/round (Android) + square/favicon.
- **Export sizes** shown in the sheet: 128 / 64 / 32 / 16. Also export the platform set (e.g. iOS up to 1024, Android 512 + adaptive, favicon 32/16, macOS 1024).
- **Small-size caveat**: below ~32px the bar+ticks+cord get muddy. For 16–24px, ship a **simplified variant**: drop the ticks and guide, keep the bar, cord, ring, and bob only (or bob + short cord). Recommend generating this as a separate simplified SVG rather than downscaling the detailed one.

## Elevation (presentation only — not baked into the icon)
Hero tile shadow (for marketing/store shots, not the raster asset): `0 30px 60px -20px oklch(0.2 0.04 285 / 0.55), 0 8px 22px -8px oklch(0.2 0.02 285 / 0.4)`. The delivered icon asset itself has no shadow.

## Assets
No external assets — the mark is 100% vector (lines, circles, polygons). Fonts on the presentation sheet only: IBM Plex Sans / Mono.

## Files
- `Plumb Tile.dc.html` — icon geometry (source of truth). *Reference only.*
- `Plumber Icon.dc.html` — presentation sheet. *Reference only.*
- (`support.js` — prototype runtime; **do not port**.)
